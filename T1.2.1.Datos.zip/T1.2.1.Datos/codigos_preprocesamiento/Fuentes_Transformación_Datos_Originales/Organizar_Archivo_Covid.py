import pandas as pd
from datetime import timedelta

data = pd.read_csv( "COVID19_Casos_Confirmados_Medellín.csv" )

data_campos = data[['GENERO', 'CODIGO_COMUNA', 'EDAD', 'FECHA_INICIO_SINTOMAS']].copy()
data_campos['FECHA_INICIO_SINTOMAS'] = pd.to_datetime(data_campos['FECHA_INICIO_SINTOMAS'], format='%d/%m/%Y')
data_campos['FECHA_FIN_CASO'] = pd.to_datetime(data_campos['FECHA_INICIO_SINTOMAS'].map(lambda x: x + timedelta(days=12)))
data_campos['CODIGO_COMUNA'] = data_campos['CODIGO_COMUNA'].map(lambda x: 0 if ( x == 'Por Ubicar' or x == ' ' ) else str(x).lstrip("0"))
data_campos.rename(columns={'GENERO' : 'CODIGO_SEXO',
                            'FECHA_INICIO_SINTOMAS' : 'FECHA_INICIO_CASO'}, inplace=True)
data_campos['EDAD'] = data_campos['EDAD'].map(lambda x: int(float(x.replace(',', '.'))) if isinstance(x, str) else x )
data_campos.sort_values(by='FECHA_INICIO_CASO', inplace=True)

data_campos.to_csv("COVID19_Casos_Confirmados_Medellín_procesado.csv", index=False, float_format='%.0f')