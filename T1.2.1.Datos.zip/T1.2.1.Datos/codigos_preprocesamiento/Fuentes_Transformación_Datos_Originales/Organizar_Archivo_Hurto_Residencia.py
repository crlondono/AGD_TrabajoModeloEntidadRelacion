import pandas as pd
from datetime import timedelta

data = pd.read_csv( "hurto_a_residencia.csv", sep=';' )

data_campos = data[['fecha_hecho', 'sexo', 'edad', 'modalidad', 'codigo_barrio', 'codigo_comuna', 'bien']].copy()
data_campos['fecha_hecho'] = pd.to_datetime(data_campos['fecha_hecho'], format='%d/%m/%Y')
data_campos['TIPO_HECHO'] = 2
data_campos['OCUPACION'] = ''

data_campos.rename(columns={'fecha_hecho' : 'FECHA_HECHO',
                            'sexo' : 'CODIGO_SEXO',
                            'edad' : 'EDAD',
                            'medio_transporte' : 'MEDIO_TRANSPORTE',
                            'modalidad' : 'MODALIDAD',
                            'codigo_barrio' : 'CODIGO_BARRIO',
                            'codigo_comuna' : 'CODIGO_COMUNA',
                            'bien' : 'BIEN' }, inplace=True)
data_campos['CODIGO_BARRIO'] = data_campos['CODIGO_BARRIO'].map(lambda x: '' if x[0:8] == 'SIN DATO' else ( x[3:] if x[0] == '#' else x ))
data_campos['CODIGO_COMUNA'] = data_campos['CODIGO_COMUNA'].map(lambda x: '' if x == 'SIN DATO' else ( '0' + x if len(x) == 1 else x ))
data_campos['CODIGO_SEXO'] = data_campos['CODIGO_SEXO'].map(lambda x: 'M' if x == 'Hombre' else 'F')

data_campos_ordenados = data_campos[['FECHA_HECHO',
                                     'TIPO_HECHO',
                                     'CODIGO_SEXO',
                                     'EDAD',
                                     'MODALIDAD',
                                     'OCUPACION',
                                     'CODIGO_COMUNA',
                                     'CODIGO_BARRIO',
                                     'BIEN']].copy()

data_campos_ordenados.to_csv("hurto_a_residencia_procesado.csv", index=False, encoding='latin1')