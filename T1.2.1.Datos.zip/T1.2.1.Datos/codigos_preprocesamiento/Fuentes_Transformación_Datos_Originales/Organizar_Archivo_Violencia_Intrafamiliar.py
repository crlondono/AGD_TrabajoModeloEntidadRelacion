import pandas as pd
from datetime import timedelta

data = pd.read_csv( "reincidencia_violencia_intrafamiliar.csv", sep=';' )

data_campos = data[['fecha_hecho', 'sexo', 'ocupacion', 'codigo_barrio', 'codigo_comuna']].copy()
data_campos['fecha_hecho'] = pd.to_datetime(data_campos['fecha_hecho'], format='%d/%m/%Y')
data_campos['TIPO_HECHO'] = 4
data_campos['EDAD'] = ''
data_campos['MODALIDAD'] = ''
data_campos['BIEN'] = ''

data_campos.rename(columns={'fecha_hecho' : 'FECHA_HECHO',
                            'sexo' : 'CODIGO_SEXO',
                            'ocupacion' : 'OCUPACION',
                            'nivel_academico' : 'NIVEL_ACADEMICO',
                            'codigo_barrio' : 'CODIGO_BARRIO',
                            'codigo_comuna' : 'CODIGO_COMUNA' }, inplace=True)
data_campos['CODIGO_BARRIO'] = data_campos['CODIGO_BARRIO'].map(lambda x: '' if x[0:8] == 'SIN DATO' else ( x[3:] if x[0] == '#' else x ))
data_campos['CODIGO_COMUNA'] = data_campos['CODIGO_COMUNA'].map(lambda x: '' if x == 'SIN DATO' else ( '0' + x if len(x) == 1 else x ))
data_campos['CODIGO_SEXO'] = data_campos['CODIGO_SEXO'].map(lambda x: 'M' if x == 'Hombre' else 'F')

data_campos_ordenados = data_campos[['FECHA_HECHO',
                                     'TIPO_HECHO',
                                     'CODIGO_SEXO',
                                     'EDAD',
                                     'MODALIDAD',
                                     'OCUPACION',
                                     'CODIGO_COMUNA',
                                     'CODIGO_BARRIO',
                                     'BIEN']].copy()

data_campos_ordenados.to_csv("reincidencia_violencia_intrafamiliar_procesado.csv", index=False, encoding='latin1')