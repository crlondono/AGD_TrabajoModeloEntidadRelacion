import pandas as pd
from datetime import datetime

data = pd.read_csv( "DimTiempo.csv", sep=';', encoding='cp1252' )

data_campos = data[['Fecha', 'Dia', 'Mes', 'Anio']].copy()
data_campos['Dia'] = data_campos['Fecha'].map(lambda x: datetime.strptime(x, '%d/%m/%Y').weekday() + 1)
data_campos['Fecha'] = pd.to_datetime(data_campos['Fecha'], format='%d/%m/%Y')

data_campos.to_csv("Dimension_Tiempo.csv", index=False)