import pandas as pd

df = pd.read_csv( "Casos_Covid_Medellin.csv", sep=';' )

df['CODIGO_COMUNA'] = df['CODIGO_COMUNA'].map(lambda x: str(int(x)).lstrip("0") if x != 0.0 else 0)

df.to_csv("Casos_Covid_Medellin_2.csv", index=False)