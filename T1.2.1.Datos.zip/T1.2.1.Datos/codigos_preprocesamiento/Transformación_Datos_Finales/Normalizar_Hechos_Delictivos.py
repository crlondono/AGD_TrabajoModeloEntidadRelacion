import pandas as pd
# from datetime import timedelta

df_extorsion = pd.read_csv( "extorsion_procesado.csv", encoding='latin1', dtype={'CODIGO_COMUNA': object} )
df_hurto_persona = pd.read_csv( "hurto_a_persona_procesado.csv", encoding='latin1', dtype={'CODIGO_COMUNA': object} )
df_hurto_Residencia = pd.read_csv( "hurto_a_residencia_procesado.csv", encoding='latin1', dtype={'CODIGO_COMUNA': object} )
df_violencia_intrafamiliar = pd.read_csv( "reincidencia_violencia_intrafamiliar_procesado.csv", encoding='latin1', dtype={'CODIGO_COMUNA': object} )

df_total = df_hurto_persona
df_total = df_total.append(df_hurto_Residencia)
df_total = df_total.append(df_extorsion)
df_total = df_total.append(df_violencia_intrafamiliar)

df_total.sort_values(by='FECHA_HECHO', inplace=True)

df_total.to_csv("Hechos_Delictivos.csv", index=False, encoding='latin1')