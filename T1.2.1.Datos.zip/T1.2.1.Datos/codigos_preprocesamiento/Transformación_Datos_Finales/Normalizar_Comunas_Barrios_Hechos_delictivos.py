import pandas as pd

def modificar_barrio(comuna, barrio):
    if comuna == '4':
        if barrio == 'Inst_9' or barrio == 'st_9':
            return 18
        if barrio == 'Inst_10' or barrio == 'st_10':
            return 19
        if barrio == 'Inst_11' or barrio == 'st_11':
            return 20
        else:
            return barrio

    if comuna == '5':
        if barrio == 'Inst_1' or barrio == 'st_1':
            return 20
        if barrio == 'Inst_2' or barrio == 'st_2':
            return 21
        if barrio == 'Inst_3' or barrio == 'st_3':
            return 22
        if barrio == 'Inst_4' or barrio == 'st_4':
            return 23
        else:
            return barrio

    if comuna == '7':
        if barrio == 'Inst_5' or barrio == 'st_5':
            return 26
        if barrio == 'Inst_6' or barrio == 'st_6':
            return 27
        if barrio == 'Inst_7' or barrio == 'st_7':
            return 28
        if barrio == 'Inst_8' or barrio == 'st_8':
            return 29
        else:
            return barrio
    
    if comuna == '10':
        if barrio == 'Inst_12' or barrio == 'st_12':
            return 21
        if barrio == 'Inst_16' or barrio == 'st_16':
            return 22
        if barrio == 'Inst_17' or barrio == 'st_17':
            return 23
        else:
            return barrio
    
    if comuna == '11':
        if barrio == 'Inst_13' or barrio == 'st_13':
            return 18
        if barrio == 'Inst_14' or barrio == 'st_14':
            return 19
        if barrio == 'Inst_15' or barrio == 'st_15':
            return 20
        else:
            return barrio
    
    if comuna == '15':
        if barrio == 'Inst_19' or barrio == 'st_19':
            return 12
        if barrio == 'Inst_20' or barrio == 'st_20':
            return 13
        else:
            return barrio
    
    if comuna == '16':
        if barrio == 'Inst_18' or barrio == 'st_18':
            return 22
        else:
            return barrio
    
    if comuna == '60':
        if barrio == 'AE1':
            return 18
        if barrio == 'AE2':
            return 19
        if barrio == 'AUC1' or barrio == 'C1':
            return 20
        else:
            return barrio
    
    if comuna == '70':
        if barrio == 'AE5':
            return 9
        if barrio == 'AE6':
            return 10
        else:
            return barrio
    
    if comuna == '80':
        if barrio == 'AE7':
            return 9
        if barrio == 'AUC2' or barrio == 'C2':
            return 10
        else:
            return barrio

    else:
        return barrio


df = pd.read_csv( "Hechos_Delictivos.csv", encoding='latin1' )

df['CODIGO_COMUNA'] = df['CODIGO_COMUNA'].fillna(0)
df['CODIGO_COMUNA'] = df['CODIGO_COMUNA'].map(lambda x: str(int(x)).lstrip("0") if x != 0.0 else 0)
df['CODIGO_BARRIO'] = df['CODIGO_BARRIO'].fillna(0)
df['CODIGO_BARRIO'] = df.apply(lambda x: modificar_barrio(x['CODIGO_COMUNA'], x['CODIGO_BARRIO']), axis=1)
df['CODIGO_BARRIO'] = df['CODIGO_BARRIO'].map(lambda x: str(int(x)).lstrip("0") if x != 0.0 else 0)

df.to_csv("Hechos_Delictivos_sin_ceros.csv", index=False, encoding='latin1', float_format='%.0f')